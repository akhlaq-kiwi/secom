<?php

// ====================================
// = PageLines Native Plugins Support =
// ====================================

/**
 *  Support WP125 Plugin
 *
 * @since 2.0.2
 */
if( function_exists('wp125_write_ads') ){
	
	
	
	// add_filter('pagelines_lesscode', 'frame_colors'); 
	// 
	// function wp125_colors( $less ){
	// 	
	// 	$less .= "#wp125adwrap_2c .wp125ad a{ background: lighten( @pl-base, @invert-light + 2 ); }";
	// 	
	// 	
	// 	return $less;
	// 	
//	}
	
}

/**
 *  Support FlickrRSS
 *
 * @since 2.0.2
 */

/**
 *  Support Instagram
 *
 * @since 2.0.2
 */
