<?php
/**
 * PAGE
 *
 * This file meets the WordPress template requirements for 'single.php'
 *
 * @package     PageLines Framework
 * @since       1.0
 *
 * @link        http://www.pagelines.com/
 * @link        http://www.pagelines.com/tour
 *
 * @author      PageLines   http://www.pagelines.com/
 * @copyright   Copyright (c) 2008-2012, PageLines  hello@pagelines.com
 *
 * @internal    last revised August 1, 2011
 * @version     ...
 *
 * @todo Define version
 */

setup_pagelines_template();
