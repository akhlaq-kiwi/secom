<?php
/**
 * SEARCH FORM
 *
 * PageLines search form
 *
 * @package     PageLines Framework
 * @since       1.0
 *
 * @link        http://www.pagelines.com/
 * @link        http://www.pagelines.com/tour
 *
 * @author      PageLines   http://www.pagelines.com/
 * @copyright   Copyright (c) 2008-2012, PageLines  hello@pagelines.com
 *
 * @usedby get_search_form
 * @internal $echo is passed from that function
 *
 * @internal    last revised January 20, 2012
 * @version     ...
 *
 * @todo Define version
 * @todo clarify *usedby and *internal
 */

pagelines_search_form( true );
